package com.sarab.keyboard16.engine

enum class LayoutMode {
    ARABIC,
    ENGLISH_LOWER,
    ENGLISH_UPPER,
    SYMBOLS,
    TASHKEEL_AND_DECOR
}

object KeyboardLayouts {

    val numberRowAr = listOf("١", "٢", "٣", "٤", "٥", "٦", "٧", "٨", "٩", "٠")
    val numberRowEn = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")

    val arabicRows = listOf(
        listOf("ض", "ص", "ث", "ق", "ف", "غ", "ع", "ه", "خ", "ح", "ج"),
        listOf("ش", "س", "ي", "ب", "ل", "ا", "ت", "ن", "م", "ك", "ط"),
        listOf("ئ", "ء", "ؤ", "ر", "لا", "ى", "ة", "و", "ز", "ظ", "ذ")
    )

    val englishLowerRows = listOf(
        listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p"),
        listOf("a", "s", "d", "f", "g", "h", "j", "k", "l"),
        listOf("z", "x", "c", "v", "b", "n", "m")
    )

    val englishUpperRows = listOf(
        listOf("Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P"),
        listOf("A", "S", "D", "F", "G", "H", "J", "K", "L"),
        listOf("Z", "X", "C", "V", "B", "N", "M")
    )

    val symbolsRows = listOf(
        listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"),
        listOf("@", "#", "$", "%", "&", "-", "+", "(", ")", "/"),
        listOf("*", """, "'", ":", ";", "!", "?", "،", "؟", ".")
    )

    val tashkeelAndDecorRows = listOf(
        listOf("َ", "ً", "ُ", "ٌ", "ِ", "ٍ", "ْ", "ّ", "ـ", "ٓ"),
        listOf("★", "☆", "♥", "♡", "❀", "✿", "❖", "✦", "✧", "♛"),
        listOf("꧁", "꧂", "«", "»", "『", "』", "【", "】", "ـہ", "ـآ")
    )

    val quickEmojis = listOf(
        "😀", "😂", "🤣", "😊", "😍", "🥰", "😘", "😎", "🤩", "🤔",
        "😅", "😢", "😭", "😡", "👍", "👎", "👏", "🙏", "🤝", "💪",
        "❤️", "💔", "🔥", "✨", "🌟", "🎉", "🌹", "🤲", "🕌", "⚡"
    )
}

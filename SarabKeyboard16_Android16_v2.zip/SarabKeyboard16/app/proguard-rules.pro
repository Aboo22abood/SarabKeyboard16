# Keep keyboard service and models
-keep class com.sarab.keyboard16.** { *; }

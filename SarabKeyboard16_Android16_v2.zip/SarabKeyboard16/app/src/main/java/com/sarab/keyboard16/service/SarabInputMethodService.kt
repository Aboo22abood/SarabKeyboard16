package com.sarab.keyboard16.service

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.media.AudioManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.sarab.keyboard16.MainActivity
import com.sarab.keyboard16.data.ClipboardStore
import com.sarab.keyboard16.data.KeyboardPrefs
import com.sarab.keyboard16.data.ShortcutsManager
import com.sarab.keyboard16.engine.DecorationEngine
import com.sarab.keyboard16.engine.KeyboardLayouts
import com.sarab.keyboard16.engine.LayoutMode

/**
 * خدمة لوحة مفاتيح سراب 16 المتوافقة مع أندرويد 16 (API 36).
 * مبنية بدون KeyboardView القديم لتعمل بسلاسة على جميع الإصدارات الحديثة.
 */
class SarabInputMethodService : InputMethodService() {

    private lateinit var prefs: KeyboardPrefs
    private lateinit var shortcutsManager: ShortcutsManager
    private lateinit var clipboardStore: ClipboardStore

    private var rootContainer: LinearLayout? = null
    private var keysContainer: LinearLayout? = null
    private var panelContainer: LinearLayout? = null

    private var currentMode: LayoutMode = LayoutMode.ARABIC
    private var isArabicLanguage: Boolean = true
    private var activePanel: String? = null // null, "CLIPBOARD", "EMOJI", "SHORTCUTS"
    private val currentWordBuffer = StringBuilder()

    private val clipboardListener = ClipboardManager.OnPrimaryClipChangedListener {
        captureSystemClipboard()
    }

    override fun onCreate() {
        super.onCreate()
        prefs = KeyboardPrefs(this)
        shortcutsManager = ShortcutsManager(this)
        clipboardStore = ClipboardStore(this)
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        cm?.addPrimaryClipChangedListener(clipboardListener)
    }

    override fun onDestroy() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        cm?.removePrimaryClipChangedListener(clipboardListener)
        super.onDestroy()
    }

    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setPadding(dp(4), dp(6), dp(4), dp(10))
        }
        rootContainer = root
        rebuildKeyboardUi()
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        currentWordBuffer.clear()
        captureSystemClipboard()
        rebuildKeyboardUi()
    }

    private fun captureSystemClipboard() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager ?: return
        val clip = cm.primaryClip ?: return
        if (clip.itemCount > 0) {
            val text = clip.getItemAt(0).coerceToText(this)?.toString().orEmpty()
            if (text.isNotBlank()) {
                clipboardStore.addClip(text)
            }
        }
    }

    private fun rebuildKeyboardUi() {
        val root = rootContainer ?: return
        val theme = prefs.theme
        root.removeAllViews()
        root.setBackgroundColor(theme.bgColor)

        // 1. شريط الأدوات العلوي (زخرفة، حافظة، اختصارات، إيموجي، تشكيل، إعدادات)
        root.addView(buildToolbar())

        // 2. لوحة فرعية اختيارية (الحافظة / الإيموجي / الاختصارات)
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        panelContainer = panel
        root.addView(panel)

        // 3. حاوية مفاتيح الكتابة
        val keysBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        keysContainer = keysBox
        root.addView(keysBox)

        if (activePanel != null) {
            keysBox.visibility = View.GONE
            renderActivePanel()
        } else {
            panel.visibility = View.GONE
            keysBox.visibility = View.VISIBLE
            renderKeys()
        }
    }

    private fun buildToolbar(): View {
        val theme = prefs.theme
        val scroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(40)
            )
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        fun addToolChip(label: String, active: Boolean = false, onClick: () -> Unit) {
            val tv = TextView(this).apply {
                text = label
                setTextColor(if (active) 0xFFFFFFFF.toInt() else theme.textColor)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                gravity = Gravity.CENTER
                setPadding(dp(12), dp(6), dp(12), dp(6))
                background = roundedBg(
                    if (active) theme.accentColor else theme.specialKeyColor,
                    dp(14).toFloat()
                )
                setOnClickListener {
                    performFeedback()
                    onClick()
                }
            }
            val lp = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                marginStart = dp(4)
                marginEnd = dp(4)
            }
            bar.addView(tv, lp)
        }

        addToolChip(
            if (prefs.decorationEnabled) "✨ الزخرفة: مفعّلة" else "✨ الزخرفة: متوقفة",
            active = prefs.decorationEnabled
        ) {
            prefs.decorationEnabled = !prefs.decorationEnabled
            rebuildKeyboardUi()
        }

        addToolChip("📋 الحافظة", active = activePanel == "CLIPBOARD") {
            activePanel = if (activePanel == "CLIPBOARD") null else "CLIPBOARD"
            rebuildKeyboardUi()
        }

        addToolChip("⚡ الاختصارات", active = activePanel == "SHORTCUTS") {
            activePanel = if (activePanel == "SHORTCUTS") null else "SHORTCUTS"
            rebuildKeyboardUi()
        }

        addToolChip("😊 إيموجي", active = activePanel == "EMOJI") {
            activePanel = if (activePanel == "EMOJI") null else "EMOJI"
            rebuildKeyboardUi()
        }

        addToolChip("ًَُ التشكيل", active = currentMode == LayoutMode.TASHKEEL_AND_DECOR && activePanel == null) {
            activePanel = null
            currentMode = if (currentMode == LayoutMode.TASHKEEL_AND_DECOR) {
                if (isArabicLanguage) LayoutMode.ARABIC else LayoutMode.ENGLISH_LOWER
            } else {
                LayoutMode.TASHKEEL_AND_DECOR
            }
            rebuildKeyboardUi()
        }

        addToolChip("⚙ الإعدادات") {
            val intent = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
        }

        scroll.addView(bar)
        return scroll
    }

    private fun renderKeys() {
        val box = keysContainer ?: return
        box.removeAllViews()

        // صف الأرقام الاختياري
        if (prefs.showNumberRow && currentMode != LayoutMode.SYMBOLS) {
            val nums = if (isArabicLanguage) KeyboardLayouts.numberRowAr else KeyboardLayouts.numberRowEn
            box.addView(buildKeyRow(nums, compact = true))
        }

        val rows = when (currentMode) {
            LayoutMode.ARABIC -> KeyboardLayouts.arabicRows
            LayoutMode.ENGLISH_LOWER -> KeyboardLayouts.englishLowerRows
            LayoutMode.ENGLISH_UPPER -> KeyboardLayouts.englishUpperRows
            LayoutMode.SYMBOLS -> KeyboardLayouts.symbolsRows
            LayoutMode.TASHKEEL_AND_DECOR -> KeyboardLayouts.tashkeelAndDecorRows
        }

        rows.forEachIndexed { index, rowKeys ->
            if (index == rows.lastIndex) {
                box.addView(buildBottomAlphaRow(rowKeys))
            } else {
                box.addView(buildKeyRow(rowKeys))
            }
        }

        // الصف السفلي (رموز، لغة، مسافة، مسح كلمة، إدخال)
        box.addView(buildActionRow())
    }

    private fun buildKeyRow(keys: List<String>, compact: Boolean = false): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(if (compact) (prefs.keyHeightDp - 8) else prefs.keyHeightDp)
            ).apply {
                topMargin = dp(3)
            }
        }
        for (label in keys) {
            row.addView(createKeyButton(label, weight = 1f, isSpecial = compact) {
                handleCharacterPress(label)
            })
        }
        return row
    }

    private fun buildBottomAlphaRow(keys: List<String>): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(prefs.keyHeightDp)
            ).apply {
                topMargin = dp(3)
            }
        }

        if (currentMode == LayoutMode.ENGLISH_LOWER || currentMode == LayoutMode.ENGLISH_UPPER) {
            val shiftLabel = if (currentMode == LayoutMode.ENGLISH_UPPER) "⬆" else "⇧"
            row.addView(createKeyButton(shiftLabel, weight = 1.4f, isSpecial = true) {
                currentMode = if (currentMode == LayoutMode.ENGLISH_LOWER) {
                    LayoutMode.ENGLISH_UPPER
                } else {
                    LayoutMode.ENGLISH_LOWER
                }
                renderKeys()
            })
        }

        for (label in keys) {
            row.addView(createKeyButton(label, weight = 1f, isSpecial = false) {
                handleCharacterPress(label)
            })
        }

        // زر الحذف (ضغط عادي يحذف حرف، ضغط مطوّل يحذف كلمة كاملة)
        val delBtn = createKeyButton("⌫", weight = 1.5f, isSpecial = true) {
            handleBackspace(deleteWord = false)
        }
        delBtn.setOnLongClickListener {
            performFeedback()
            handleBackspace(deleteWord = true)
            true
        }
        row.addView(delBtn)

        return row
    }

    private fun buildActionRow(): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(prefs.keyHeightDp)
            ).apply {
                topMargin = dp(4)
            }
        }

        row.addView(createKeyButton(if (currentMode == LayoutMode.SYMBOLS) "أبج" else "123", weight = 1.3f, isSpecial = true) {
            currentMode = if (currentMode == LayoutMode.SYMBOLS) {
                if (isArabicLanguage) LayoutMode.ARABIC else LayoutMode.ENGLISH_LOWER
            } else {
                LayoutMode.SYMBOLS
            }
            renderKeys()
        })

        row.addView(createKeyButton(if (isArabicLanguage) "EN" else "عربي", weight = 1.2f, isSpecial = true) {
            isArabicLanguage = !isArabicLanguage
            currentMode = if (isArabicLanguage) LayoutMode.ARABIC else LayoutMode.ENGLISH_LOWER
            currentWordBuffer.clear()
            renderKeys()
        })

        val spaceTitle = if (prefs.decorationEnabled) "مسافة (سراب 16 ✨)" else "مسافة (سراب 16)"
        row.addView(createKeyButton(spaceTitle, weight = 4.2f, isSpecial = false) {
            handleSpacePress()
        })

        row.addView(createKeyButton("،", weight = 0.9f, isSpecial = true) {
            handleCharacterPress(if (isArabicLanguage) "،" else ".")
        })

        row.addView(createKeyButton("↵", weight = 1.5f, isSpecial = true, useAccent = true) {
            handleEnterPress()
        })

        return row
    }

    private fun createKeyButton(
        label: String,
        weight: Float,
        isSpecial: Boolean,
        useAccent: Boolean = false,
        onClick: () -> Unit
    ): Button {
        val theme = prefs.theme
        val bg = when {
            useAccent -> theme.accentColor
            isSpecial -> theme.specialKeyColor
            else -> theme.keyColor
        }
        return Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(if (useAccent) 0xFFFFFFFF.toInt() else theme.textColor)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, if (label.length > 2) 13f else prefs.fontSizeSp)
            background = roundedBg(bg, dp(8).toFloat())
            setPadding(0, 0, 0, 0)
            minWidth = 0
            minimumWidth = 0
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight).apply {
                marginStart = dp(2)
                marginEnd = dp(2)
            }
            setOnClickListener {
                performFeedback()
                onClick()
            }
        }
    }

    private fun renderActivePanel() {
        val panel = panelContainer ?: return
        val theme = prefs.theme
        panel.visibility = View.VISIBLE
        panel.removeAllViews()

        val scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(210)
            )
        }
        val listLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }

        when (activePanel) {
            "CLIPBOARD" -> {
                val clips = clipboardStore.getAll()
                if (clips.isEmpty()) {
                    listLayout.addView(infoText("الحافظة فارغة حالياً. انسخ أي نص ليظهر هنا تلقائياً."))
                } else {
                    for (clip in clips) {
                        val row = LinearLayout(this).apply {
                            orientation = LinearLayout.HORIZONTAL
                            background = roundedBg(theme.keyColor, dp(10).toFloat())
                            setPadding(dp(10), dp(8), dp(10), dp(8))
                            layoutParams = LinearLayout.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.WRAP_CONTENT
                            ).apply { bottomMargin = dp(6) }
                        }
                        val tv = TextView(this).apply {
                            text = (if (clip.pinned) "📌 " else "") + clip.text
                            maxLines = 2
                            setTextColor(theme.textColor)
                            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                            setOnClickListener {
                                performFeedback()
                                currentInputConnection?.commitText(clip.text, 1)
                            }
                        }
                        val pinBtn = TextView(this).apply {
                            text = if (clip.pinned) "إلغاء" else "تثبيت"
                            setTextColor(theme.accentColor)
                            setPadding(dp(8), 0, dp(8), 0)
                            setOnClickListener {
                                clipboardStore.togglePin(clip.text)
                                renderActivePanel()
                            }
                        }
                        val delBtn = TextView(this).apply {
                            text = "✕"
                            setTextColor(0xFFEF5350.toInt())
                            setPadding(dp(6), 0, dp(4), 0)
                            setOnClickListener {
                                clipboardStore.deleteClip(clip.text)
                                renderActivePanel()
                            }
                        }
                        row.addView(tv)
                        row.addView(pinBtn)
                        row.addView(delBtn)
                        listLayout.addView(row)
                    }
                }
            }

            "SHORTCUTS" -> {
                val shortcuts = shortcutsManager.getAll()
                if (shortcuts.isEmpty()) {
                    listLayout.addView(infoText("لا توجد اختصارات بعد. أضف اختصاراتك من شاشة الإعدادات."))
                } else {
                    for (sc in shortcuts) {
                        val itemView = TextView(this).apply {
                            text = "⚡ [${sc.trigger}]  ←  ${sc.expansion}"
                            setTextColor(theme.textColor)
                            background = roundedBg(theme.keyColor, dp(10).toFloat())
                            setPadding(dp(12), dp(10), dp(12), dp(10))
                            layoutParams = LinearLayout.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.WRAP_CONTENT
                            ).apply { bottomMargin = dp(6) }
                            setOnClickListener {
                                performFeedback()
                                currentInputConnection?.commitText(sc.expansion + " ", 1)
                            }
                        }
                        listLayout.addView(itemView)
                    }
                }
            }

            "EMOJI" -> {
                val chunked = KeyboardLayouts.quickEmojis.chunked(6)
                for (rowEmojis in chunked) {
                    val row = LinearLayout(this).apply {
                        orientation = LinearLayout.HORIZONTAL
                        layoutParams = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            dp(44)
                        )
                    }
                    for (emoji in rowEmojis) {
                        val btn = TextView(this).apply {
                            text = emoji
                            gravity = Gravity.CENTER
                            setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
                            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                            setOnClickListener {
                                performFeedback()
                                currentInputConnection?.commitText(emoji, 1)
                            }
                        }
                        row.addView(btn)
                    }
                    listLayout.addView(row)
                }
            }
        }

        scroll.addView(listLayout)
        panel.addView(scroll)
    }

    private fun handleCharacterPress(raw: String) {
        val ic = currentInputConnection ?: return
        val output = if (prefs.decorationEnabled && raw.length == 1) {
            val ch = raw[0]
            when {
                ch in 'ء'..'ي' -> DecorationEngine.decorateCharArabic(ch, prefs.arabicDecorationStyle)
                ch in 'A'..'Z' || ch in 'a'..'z' -> DecorationEngine.decorateCharEnglish(ch, prefs.englishDecorationStyle)
                else -> raw
            }
        } else {
            raw
        }

        ic.commitText(output, 1)
        currentWordBuffer.append(raw)
    }

    private fun handleSpacePress() {
        val ic = currentInputConnection ?: return
        val typedWord = currentWordBuffer.toString().trim()

        if (prefs.shortcutsEnabled && typedWord.isNotEmpty()) {
            val expanded = shortcutsManager.findExpansion(typedWord)
            if (expanded != null) {
                ic.deleteSurroundingText(typedWord.length, 0)
                val finalOut = if (prefs.decorationEnabled) {
                    DecorationEngine.decorateWordOrPhraseArabic(expanded, prefs.arabicDecorationStyle)
                } else {
                    expanded
                }
                ic.commitText("$finalOut ", 1)
                currentWordBuffer.clear()
                return
            }
        }

        ic.commitText(" ", 1)
        currentWordBuffer.clear()
    }

    private fun handleBackspace(deleteWord: Boolean) {
        val ic = currentInputConnection ?: return
        if (deleteWord) {
            val before = ic.getTextBeforeCursor(40, 0)?.toString().orEmpty()
            val trimmed = before.trimEnd()
            val lastSpace = trimmed.lastIndexOf(' ')
            val count = if (lastSpace == -1) before.length else (before.length - lastSpace - 1)
            if (count > 0) {
                ic.deleteSurroundingText(count, 0)
            }
            currentWordBuffer.clear()
        } else {
            ic.deleteSurroundingText(1, 0)
            if (currentWordBuffer.isNotEmpty()) {
                currentWordBuffer.deleteCharAt(currentWordBuffer.length - 1)
            }
        }
    }

    private fun handleEnterPress() {
        currentWordBuffer.clear()
        currentInputConnection?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
        currentInputConnection?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
    }

    private fun performFeedback() {
        if (prefs.vibrationEnabled) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator?.vibrate(VibrationEffect.createOneShot(18, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                val v = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v?.vibrate(VibrationEffect.createOneShot(18, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    v?.vibrate(18)
                }
            }
        }
        if (prefs.soundEnabled) {
            val am = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            am?.playSoundEffect(AudioManager.FX_KEY_CLICK, 0.5f)
        }
    }

    private fun infoText(msg: String): TextView = TextView(this).apply {
        text = msg
        setTextColor(prefs.theme.textColor)
        gravity = Gravity.CENTER
        setPadding(dp(12), dp(24), dp(12), dp(24))
    }

    private fun roundedBg(color: Int, radius: Float): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
    }

    private fun dp(value: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value.toFloat(), resources.displayMetrics).toInt()
}

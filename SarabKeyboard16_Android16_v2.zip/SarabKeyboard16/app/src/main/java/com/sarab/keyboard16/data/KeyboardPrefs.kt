package com.sarab.keyboard16.data

import android.content.Context
import android.content.SharedPreferences

enum class KeyboardTheme(
    val id: String,
    val titleAr: String,
    val bgColor: Int,
    val keyColor: Int,
    val specialKeyColor: Int,
    val textColor: Int,
    val accentColor: Int
) {
    ROYAL_DARK(
        "royal_dark", "الداكن الملكي",
        0xFF141824.toInt(), 0xFF23293A.toInt(), 0xFF1C2233.toInt(),
        0xFFFFFFFF.toInt(), 0xFF42A5F5.toInt()
    ),
    AMOLED_BLACK(
        "amoled_black", "أسود AMOLED",
        0xFF000000.toInt(), 0xFF1A1A1A.toInt(), 0xFF111111.toInt(),
        0xFFFFFFFF.toInt(), 0xFF00E5FF.toInt()
    ),
    NEON_BLUE(
        "neon_blue", "نيون أزرق",
        0xFF0B132B.toInt(), 0xFF1C2541.toInt(), 0xFF3A506B.toInt(),
        0xFFE0FBFC.toInt(), 0xFF5BC0BE.toInt()
    ),
    CLASSIC_LIGHT(
        "classic_light", "أبيض كلاسيكي",
        0xFFE8ECF2.toInt(), 0xFFFFFFFF.toInt(), 0xFFD0D7E2.toInt(),
        0xFF1A1F2C.toInt(), 0xFF1565C0.toInt()
    ),
    GOLD_LUXURY(
        "gold_luxury", "ذهبي فاخر",
        0xFF181512.toInt(), 0xFF2B251E.toInt(), 0xFF221D17.toInt(),
        0xFFFFE082.toInt(), 0xFFFFB300.toInt()
    );

    companion object {
        fun fromId(id: String?): KeyboardTheme =
            entries.firstOrNull { it.id == id } ?: ROYAL_DARK
    }
}

class KeyboardPrefs(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("sarab_keyboard_prefs", Context.MODE_PRIVATE)

    var decorationEnabled: Boolean
        get() = prefs.getBoolean("decoration_enabled", false)
        set(value) = prefs.edit().putBoolean("decoration_enabled", value).apply()

    var arabicDecorationStyle: Int
        get() = prefs.getInt("ar_dec_style", 0)
        set(value) = prefs.edit().putInt("ar_dec_style", value).apply()

    var englishDecorationStyle: Int
        get() = prefs.getInt("en_dec_style", 0)
        set(value) = prefs.edit().putInt("en_dec_style", value).apply()

    var showNumberRow: Boolean
        get() = prefs.getBoolean("show_number_row", true)
        set(value) = prefs.edit().putBoolean("show_number_row", value).apply()

    var vibrationEnabled: Boolean
        get() = prefs.getBoolean("vibration_enabled", true)
        set(value) = prefs.edit().putBoolean("vibration_enabled", value).apply()

    var soundEnabled: Boolean
        get() = prefs.getBoolean("sound_enabled", false)
        set(value) = prefs.edit().putBoolean("sound_enabled", value).apply()

    var shortcutsEnabled: Boolean
        get() = prefs.getBoolean("shortcuts_enabled", true)
        set(value) = prefs.edit().putBoolean("shortcuts_enabled", value).apply()

    var keyHeightDp: Int
        get() = prefs.getInt("key_height_dp", 48)
        set(value) = prefs.edit().putInt("key_height_dp", value.coerceIn(38, 64)).apply()

    var fontSizeSp: Float
        get() = prefs.getFloat("font_size_sp", 18f)
        set(value) = prefs.edit().putFloat("font_size_sp", value.coerceIn(14f, 24f)).apply()

    var theme: KeyboardTheme
        get() = KeyboardTheme.fromId(prefs.getString("theme_id", KeyboardTheme.ROYAL_DARK.id))
        set(value) = prefs.edit().putString("theme_id", value.id).apply()
}

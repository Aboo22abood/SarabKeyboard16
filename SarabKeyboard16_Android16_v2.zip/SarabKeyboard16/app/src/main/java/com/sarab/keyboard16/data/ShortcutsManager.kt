package com.sarab.keyboard16.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class TextShortcut(
    val trigger: String,
    val expansion: String
)

/**
 * إدارة الاختصارات النصية مع النسخ الاحتياطي والاستعادة بصيغة JSON.
 */
class ShortcutsManager(context: Context) {
    private val prefs = context.getSharedPreferences("sarab_shortcuts_store", Context.MODE_PRIVATE)
    private val keyList = "shortcuts_json"

    init {
        if (!prefs.contains(keyList)) {
            saveAll(defaultShortcuts())
        }
    }

    fun getAll(): MutableList<TextShortcut> {
        val raw = prefs.getString(keyList, "[]") ?: "[]"
        val result = mutableListOf<TextShortcut>()
        runCatching {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val t = obj.optString("trigger").trim()
                val e = obj.optString("expansion")
                if (t.isNotEmpty() && e.isNotEmpty()) {
                    result.add(TextShortcut(t, e))
                }
            }
        }
        return result
    }

    fun findExpansion(trigger: String): String? {
        val normalized = trigger.trim()
        return getAll().firstOrNull { it.trigger == normalized }?.expansion
    }

    fun addOrUpdate(trigger: String, expansion: String) {
        val cleanTrigger = trigger.trim()
        if (cleanTrigger.isEmpty() || expansion.isEmpty()) return
        val list = getAll()
        list.removeAll { it.trigger == cleanTrigger }
        list.add(0, TextShortcut(cleanTrigger, expansion))
        saveAll(list)
    }

    fun remove(trigger: String) {
        val list = getAll()
        list.removeAll { it.trigger == trigger }
        saveAll(list)
    }

    fun exportToJson(): String {
        val arr = JSONArray()
        for (item in getAll()) {
            val obj = JSONObject()
            obj.put("trigger", item.trigger)
            obj.put("expansion", item.expansion)
            arr.put(obj)
        }
        return arr.toString(2)
    }

    fun importFromJson(jsonText: String, merge: Boolean = true): Int {
        val incoming = mutableListOf<TextShortcut>()
        val arr = JSONArray(jsonText)
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            val t = obj.optString("trigger").trim()
            val e = obj.optString("expansion")
            if (t.isNotEmpty() && e.isNotEmpty()) {
                incoming.add(TextShortcut(t, e))
            }
        }
        val finalList = if (merge) {
            val existing = getAll()
            for (item in incoming) {
                existing.removeAll { it.trigger == item.trigger }
                existing.add(item)
            }
            existing
        } else {
            incoming
        }
        saveAll(finalList)
        return incoming.size
    }

    private fun saveAll(list: List<TextShortcut>) {
        val arr = JSONArray()
        for (item in list) {
            val obj = JSONObject()
            obj.put("trigger", item.trigger)
            obj.put("expansion", item.expansion)
            arr.put(obj)
        }
        prefs.edit().putString(keyList, arr.toString()).apply()
    }

    private fun defaultShortcuts(): List<TextShortcut> = listOf(
        TextShortcut("س", "السلام عليكم ورحمة الله وبركاته"),
        TextShortcut("و", "وعليكم السلام ورحمة الله وبركاته"),
        TextShortcut("ح", "الحمد لله رب العالمين"),
        TextShortcut("ش", "شكراً جزيلاً، يعطيك العافية"),
        TextShortcut("ص", "اللهم صلِّ وسلم على نبينا محمد"),
        TextShortcut("م", "مساء الخير، كيف الحال؟"),
        TextShortcut("صب", "صباح الخير والنور")
    )
}

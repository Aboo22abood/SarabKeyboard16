package com.sarab.keyboard16.engine

/**
 * محرك الزخرفة الفورية (عربي وإنجليزي) المستوحى من كيبورد السراب البعيد.
 */
object DecorationEngine {

    val arabicStyleNames = listOf(
        "زخرفة التطويل الملكية (كـتـابـة)",
        "زخرفة التشكيل الاحترافية (كَتِابَة)",
        "زخرفة الحروف المميزة (گتآبـة)",
        "زخرفة النجوم والرموز (★ نص ★)",
        "زخرفة الأجنحة الفخمة (꧁ نص ꧂)"
    )

    val englishStyleNames = listOf(
        "Bold Serif (𝐀𝐁𝐂)",
        "Script Fancy (𝒜𝐵𝒞)",
        "Double Struck (𝔸𝔹ℂ)",
        "Monospace (𝙰𝙱𝙲)",
        "Small Caps (ᴀʙᴄ)"
    )

    private val stretchableArabic = setOf(
        'ب', 'ت', 'ث', 'ج', 'ح', 'خ', 'س', 'ش', 'ص', 'ض',
        'ط', 'ظ', 'ع', 'غ', 'ف', 'ق', 'ك', 'ل', 'م', 'ن', 'ه', 'ي', 'ئ'
    )

    private val stylishArabicMap = mapOf(
        'ا' to "آ",
        'أ' to "أّ",
        'ب' to "بّ",
        'ت' to "تٌ",
        'ث' to "ثً",
        'ج' to "جٍ",
        'ح' to "حً",
        'خ' to "خـ",
        'س' to "سـ",
        'ش' to "شـ",
        'ص' to "صـ",
        'ض' to "ضـ",
        'ع' to "عٌ",
        'غ' to "غـ",
        'ف' to "فُ",
        'ق' to "قـ",
        'ك' to "گ",
        'ل' to "لُ",
        'م' to "مـ",
        'ن' to "نِ",
        'ه' to "هـ",
        'و' to "وٌ",
        'ي' to "يَ"
    )

    private val tashkeelCycle = charArrayOf('َ', 'ِ', 'ُ', 'ْ')

    fun decorateCharArabic(ch: Char, styleIndex: Int): String {
        return when (styleIndex) {
            0 -> if (ch in stretchableArabic) "${ch}ـ" else ch.toString()
            1 -> if (ch in 'ء'..'ي') {
                val mark = tashkeelCycle[ch.code % tashkeelCycle.size]
                "$ch$mark"
            } else ch.toString()
            2 -> stylishArabicMap[ch] ?: ch.toString()
            3 -> if (ch in stretchableArabic) "${ch}ـ" else ch.toString()
            4 -> if (ch in stretchableArabic) "${ch}ـ" else ch.toString()
            else -> ch.toString()
        }
    }

    fun decorateWordOrPhraseArabic(text: String, styleIndex: Int): String {
        val core = text.map { decorateCharArabic(it, styleIndex) }.joinToString("")
        return when (styleIndex) {
            3 -> "★ $core ★"
            4 -> "꧁ $core ꧂"
            else -> core
        }
    }

    fun decorateCharEnglish(ch: Char, styleIndex: Int): String {
        return when (styleIndex) {
            0 -> mapUnicodeOffset(ch, 0x1D400, 0x1D41A) // Bold Serif
            1 -> mapUnicodeOffset(ch, 0x1D4D0, 0x1D4EA) // Bold Script
            2 -> mapUnicodeOffset(ch, 0x1D538, 0x1D552) // Double-Struck
            3 -> mapUnicodeOffset(ch, 0x1D670, 0x1D68A) // Monospace
            4 -> mapSmallCaps(ch)
            else -> ch.toString()
        }
    }

    private fun mapUnicodeOffset(ch: Char, upperStart: Int, lowerStart: Int): String {
        return when (ch) {
            in 'A'..'Z' -> String(Character.toChars(upperStart + (ch - 'A')))
            in 'a'..'z' -> String(Character.toChars(lowerStart + (ch - 'a')))
            else -> ch.toString()
        }
    }

    private fun mapSmallCaps(ch: Char): String {
        val smallCaps = "ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀsᴛᴜᴠᴡxʏᴢ"
        val lower = ch.lowercaseChar()
        return if (lower in 'a'..'z') smallCaps[lower - 'a'].toString() else ch.toString()
    }
}

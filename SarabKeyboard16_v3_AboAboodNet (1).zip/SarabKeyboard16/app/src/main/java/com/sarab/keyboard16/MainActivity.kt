package com.sarab.keyboard16

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.sarab.keyboard16.data.ClipboardStore
import com.sarab.keyboard16.data.KeyboardPrefs
import com.sarab.keyboard16.data.KeyboardTheme
import com.sarab.keyboard16.data.ShortcutsManager
import com.sarab.keyboard16.engine.DecorationEngine

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: KeyboardPrefs
    private lateinit var shortcutsManager: ShortcutsManager
    private lateinit var clipboardStore: ClipboardStore
    private lateinit var shortcutsContainer: LinearLayout

    private val exportLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(shortcutsManager.exportToJson().toByteArray(Charsets.UTF_8))
                }
                toast("تم تصدير النسخة الاحتياطية للاختصارات بنجاح")
            }.onFailure {
                toast("تعذّر حفظ الملف: ${it.message}")
            }
        }
    }

    private val importLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                val json = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty()
                val count = shortcutsManager.importFromJson(json, merge = true)
                refreshShortcutsList()
                toast("تم استيراد $count اختصار بنجاح")
            }.onFailure {
                toast("ملف النسخة الاحتياطية غير صالح")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = KeyboardPrefs(this)
        shortcutsManager = ShortcutsManager(this)
        clipboardStore = ClipboardStore(this)
        shortcutsContainer = findViewById(R.id.shortcutsListContainer)

        setupActivationButtons()
        setupAppearanceAndFeedback()
        setupDecorationControls()
        setupManualClipboardAdd()
        setupShortcutsControls()
    }

    private fun setupActivationButtons() {
        findViewById<Button>(R.id.btnEnableKeyboard).setOnClickListener {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }
        findViewById<Button>(R.id.btnSelectKeyboard).setOnClickListener {
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showInputMethodPicker()
        }
    }

    private fun setupAppearanceAndFeedback() {
        val spinnerTheme = findViewById<Spinner>(R.id.spinnerTheme)
        val themes = KeyboardTheme.entries
        spinnerTheme.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            themes.map { it.titleAr }
        )
        spinnerTheme.setSelection(themes.indexOf(prefs.theme))

        val switchNumbers = findViewById<Switch>(R.id.switchNumberRow).apply {
            isChecked = prefs.showNumberRow
            setOnCheckedChangeListener { _, checked ->
                prefs.showNumberRow = checked
                prefs.bumpVersion()
            }
        }
        val switchVibration = findViewById<Switch>(R.id.switchVibration).apply {
            isChecked = prefs.vibrationEnabled
            setOnCheckedChangeListener { _, checked -> prefs.vibrationEnabled = checked }
        }
        val switchSound = findViewById<Switch>(R.id.switchSound).apply {
            isChecked = prefs.soundEnabled
            setOnCheckedChangeListener { _, checked -> prefs.soundEnabled = checked }
        }
        val switchShortcuts = findViewById<Switch>(R.id.switchShortcuts).apply {
            isChecked = prefs.shortcutsEnabled
            setOnCheckedChangeListener { _, checked -> prefs.shortcutsEnabled = checked }
        }

        val seekHeight = findViewById<SeekBar>(R.id.seekKeyHeight).apply {
            max = 24
            progress = prefs.keyHeightDp - 38
        }
        val tvHeight = findViewById<TextView>(R.id.tvKeyHeightLabel).apply {
            text = "ارتفاع المفاتيح: ${prefs.keyHeightDp}dp"
        }
        seekHeight.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                val h = 38 + progress
                prefs.keyHeightDp = h
                prefs.bumpVersion()
                tvHeight.text = "ارتفاع المفاتيح: ${h}dp"
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        findViewById<Button>(R.id.btnSaveTheme).setOnClickListener {
            prefs.theme = themes[spinnerTheme.selectedItemPosition]
            prefs.showNumberRow = switchNumbers.isChecked
            prefs.vibrationEnabled = switchVibration.isChecked
            prefs.soundEnabled = switchSound.isChecked
            prefs.shortcutsEnabled = switchShortcuts.isChecked
            prefs.bumpVersion()
            toast("تم حفظ المظهر وتحديث الكيبورد فوراً")
        }
    }

    private fun setupDecorationControls() {
        val switchDecor = findViewById<Switch>(R.id.switchDecoration).apply {
            isChecked = prefs.decorationEnabled
            setOnCheckedChangeListener { _, checked ->
                prefs.decorationEnabled = checked
                prefs.bumpVersion()
            }
        }
        val spinnerAr = findViewById<Spinner>(R.id.spinnerArStyle).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                DecorationEngine.arabicStyleNames
            )
            setSelection(prefs.arabicDecorationStyle.coerceIn(0, DecorationEngine.arabicStyleNames.lastIndex))
        }
        val spinnerEn = findViewById<Spinner>(R.id.spinnerEnStyle).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                DecorationEngine.englishStyleNames
            )
            setSelection(prefs.englishDecorationStyle.coerceIn(0, DecorationEngine.englishStyleNames.lastIndex))
        }

        findViewById<Button>(R.id.btnSaveDecor).setOnClickListener {
            prefs.decorationEnabled = switchDecor.isChecked
            prefs.arabicDecorationStyle = spinnerAr.selectedItemPosition
            prefs.englishDecorationStyle = spinnerEn.selectedItemPosition
            prefs.bumpVersion()
            toast("تم حفظ أنماط الزخرفة")
        }
    }

    private fun setupManualClipboardAdd() {
        val etClip = findViewById<EditText>(R.id.etManualClip)
        findViewById<Button>(R.id.btnAddClip).setOnClickListener {
            val text = etClip.text.toString().trim()
            if (text.isEmpty()) {
                toast("اكتب نصاً لحفظه في الحافظة أولاً")
                return@setOnClickListener
            }
            clipboardStore.addClip(text)
            clipboardStore.togglePin(text)
            etClip.text.clear()
            toast("تم حفظ وتثبيت النص في حافظة الكيبورد")
        }
    }

    private fun setupShortcutsControls() {
        val etTrigger = findViewById<EditText>(R.id.etShortcutTrigger)
        val etExpansion = findViewById<EditText>(R.id.etShortcutExpansion)

        findViewById<Button>(R.id.btnAddShortcut).setOnClickListener {
            val trigger = etTrigger.text.toString().trim()
            val expansion = etExpansion.text.toString().trim()
            if (trigger.isEmpty() || expansion.isEmpty()) {
                toast("أدخل الاختصار والنص الكامل أولاً")
                return@setOnClickListener
            }
            shortcutsManager.addOrUpdate(trigger, expansion)
            etTrigger.text.clear()
            etExpansion.text.clear()
            refreshShortcutsList()
            toast("تم حفظ الاختصار بنجاح")
        }

        findViewById<Button>(R.id.btnExportShortcuts).setOnClickListener {
            exportLauncher.launch("abo_abood_net_shortcuts.json")
        }

        findViewById<Button>(R.id.btnImportShortcuts).setOnClickListener {
            importLauncher.launch(arrayOf("application/json", "text/plain"))
        }

        refreshShortcutsList()
    }

    private fun refreshShortcutsList() {
        shortcutsContainer.removeAllViews()
        for (sc in shortcutsManager.getAll()) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(8, 10, 8, 10)
            }
            val tv = TextView(this).apply {
                text = "⚡ [${sc.trigger}]  ←  ${sc.expansion}"
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            val del = Button(this).apply {
                text = "حذف"
                setOnClickListener {
                    shortcutsManager.remove(sc.trigger)
                    refreshShortcutsList()
                }
            }
            row.addView(tv)
            row.addView(del)
            shortcutsContainer.addView(row)
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}

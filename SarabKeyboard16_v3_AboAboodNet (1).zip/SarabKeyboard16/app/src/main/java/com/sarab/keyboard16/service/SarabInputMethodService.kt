package com.sarab.keyboard16.service

import android.annotation.SuppressLint
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.sarab.keyboard16.MainActivity
import com.sarab.keyboard16.data.ClipboardStore
import com.sarab.keyboard16.data.KeyboardPrefs
import com.sarab.keyboard16.data.ShortcutsManager
import com.sarab.keyboard16.engine.DecorationEngine
import com.sarab.keyboard16.engine.KeyboardLayouts
import com.sarab.keyboard16.engine.LayoutMode

/**
 * كيبورد أبو عبود نت — إصدار أندرويد 16 فائق السرعة
 * - استجابة فورية بدون تأخير (Touch-optimized TextView keys)
 * - شريط أدوات ثابت واضح يشمل الحافظة والزخرفة والاختصارات والإيموجي والتشكيل
 * - حافظة متكاملة مع شريط لصق سريع + نسخ/لصق/تحديد الكل + تثبيت
 * - حذف مستمر سريع عند الضغط المطول على Backspace
 */
class SarabInputMethodService : InputMethodService() {

    private lateinit var prefs: KeyboardPrefs
    private lateinit var shortcutsManager: ShortcutsManager
    private lateinit var clipboardStore: ClipboardStore
    private var audioManager: AudioManager? = null
    private var clipboardManager: ClipboardManager? = null

    private var rootContainer: LinearLayout? = null
    private var toolbarContainer: LinearLayout? = null
    private var quickPasteStrip: LinearLayout? = null
    private var keysContainer: LinearLayout? = null
    private var panelContainer: LinearLayout? = null

    private var currentMode: LayoutMode = LayoutMode.ARABIC
    private var isArabicLanguage: Boolean = true
    private var activePanel: String? = null // null, "CLIPBOARD", "EMOJI", "SHORTCUTS"
    private var lastAppliedVersion: Int = -1
    private val currentWordBuffer = StringBuilder()

    private val handler = Handler(Looper.getMainLooper())
    private var backspaceRepeating = false
    private var backspaceCount = 0

    private val backspaceRunnable = object : Runnable {
        override fun run() {
            if (!backspaceRepeating) return
            backspaceCount++
            handleBackspace(deleteWord = backspaceCount > 10)
            val delay = if (backspaceCount > 10) 90L else 55L
            handler.postDelayed(this, delay)
        }
    }

    private val clipboardListener = ClipboardManager.OnPrimaryClipChangedListener {
        captureSystemClipboard()
        updateQuickPasteStrip()
        if (activePanel == "CLIPBOARD") {
            renderActivePanel()
        }
    }

    override fun onCreate() {
        super.onCreate()
        prefs = KeyboardPrefs(this)
        shortcutsManager = ShortcutsManager(this)
        clipboardStore = ClipboardStore(this)
        audioManager = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        clipboardManager = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        clipboardManager?.addPrimaryClipChangedListener(clipboardListener)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        clipboardManager?.removePrimaryClipChangedListener(clipboardListener)
        super.onDestroy()
    }

    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setPadding(dp(4), dp(4), dp(4), dp(8))
        }
        rootContainer = root
        lastAppliedVersion = prefs.versionTag
        buildFullLayout()
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        currentWordBuffer.clear()
        captureSystemClipboard()

        // إعادة البناء الكامل فقط إذا تغيرت الإعدادات من التطبيق، ليبقى الكيبورد سريعاً جداً
        if (lastAppliedVersion != prefs.versionTag || rootContainer == null) {
            lastAppliedVersion = prefs.versionTag
            buildFullLayout()
        } else {
            updateQuickPasteStrip()
        }
    }

    private fun captureSystemClipboard() {
        val cm = clipboardManager ?: return
        runCatching {
            val clip = cm.primaryClip ?: return
            if (clip.itemCount > 0) {
                val text = clip.getItemAt(0).coerceToText(this)?.toString().orEmpty()
                if (text.isNotBlank()) {
                    clipboardStore.addClip(text)
                }
            }
        }
    }

    private fun buildFullLayout() {
        val root = rootContainer ?: return
        val theme = prefs.theme
        root.removeAllViews()
        root.setBackgroundColor(theme.bgColor)

        // 1. شريط الأدوات الثابت (6 أزرار واضحة بدون تمرير)
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(theme.toolbarColor)
            setPadding(dp(2), dp(4), dp(2), dp(4))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(40)
            )
        }
        toolbarContainer = toolbar
        root.addView(toolbar)
        renderToolbar()

        // 2. شريط اللصق السريع من الحافظة + أسهم تحريك المؤشر
        val pasteStrip = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(3), dp(4), dp(3))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        quickPasteStrip = pasteStrip
        root.addView(pasteStrip)
        updateQuickPasteStrip()

        // 3. حاوية اللوحات (الحافظة / الاختصارات / الإيموجي)
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        panelContainer = panel
        root.addView(panel)

        // 4. حاوية المفاتيح
        val keysBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        keysContainer = keysBox
        root.addView(keysBox)

        refreshMainBody()
    }

    private fun refreshMainBody() {
        val panel = panelContainer ?: return
        val keysBox = keysContainer ?: return
        renderToolbar()
        if (activePanel != null) {
            keysBox.visibility = View.GONE
            panel.visibility = View.VISIBLE
            renderActivePanel()
        } else {
            panel.visibility = View.GONE
            keysBox.visibility = View.VISIBLE
            renderKeys()
        }
    }

    private fun renderToolbar() {
        val bar = toolbarContainer ?: return
        val theme = prefs.theme
        bar.removeAllViews()

        fun addToolBtn(
            label: String,
            active: Boolean = false,
            onLongClick: (() -> Unit)? = null,
            onClick: () -> Unit
        ) {
            val tv = TextView(this).apply {
                text = label
                gravity = Gravity.CENTER
                maxLines = 1
                setTextColor(if (active) 0xFF07131F.toInt() else theme.textColor)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
                typeface = Typeface.DEFAULT_BOLD
                background = roundedBg(
                    if (active) theme.accentColor else theme.specialKeyColor,
                    dp(10).toFloat(),
                    if (active) theme.accentColor else theme.borderColor
                )
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                    marginStart = dp(2)
                    marginEnd = dp(2)
                }
                setOnClickListener {
                    performFeedback(this)
                    onClick()
                }
                if (onLongClick != null) {
                    setOnLongClickListener {
                        performFeedback(this)
                        onLongClick()
                        true
                    }
                }
            }
            bar.addView(tv)
        }

        // زر الزخرفة (ضغط عادي: تشغيل/إيقاف — ضغط مطول: تبديل نمط الزخرفة فوراً!)
        addToolBtn(
            if (prefs.decorationEnabled) "✨ زخرفة" else "زخرفة",
            active = prefs.decorationEnabled,
            onLongClick = {
                val nextStyle = (prefs.arabicDecorationStyle + 1) % DecorationEngine.arabicStyleNames.size
                prefs.arabicDecorationStyle = nextStyle
                prefs.decorationEnabled = true
                renderToolbar()
                updateQuickPasteStrip()
            }
        ) {
            prefs.decorationEnabled = !prefs.decorationEnabled
            renderToolbar()
            renderKeys()
            updateQuickPasteStrip()
        }

        addToolBtn("📋 حافظة", active = activePanel == "CLIPBOARD") {
            captureSystemClipboard()
            activePanel = if (activePanel == "CLIPBOARD") null else "CLIPBOARD"
            refreshMainBody()
        }

        addToolBtn("⚡ اختصار", active = activePanel == "SHORTCUTS") {
            activePanel = if (activePanel == "SHORTCUTS") null else "SHORTCUTS"
            refreshMainBody()
        }

        addToolBtn("😊 إيموجي", active = activePanel == "EMOJI") {
            activePanel = if (activePanel == "EMOJI") null else "EMOJI"
            refreshMainBody()
        }

        addToolBtn("ًَُ تشكيل", active = currentMode == LayoutMode.TASHKEEL_AND_DECOR && activePanel == null) {
            activePanel = null
            currentMode = if (currentMode == LayoutMode.TASHKEEL_AND_DECOR) {
                if (isArabicLanguage) LayoutMode.ARABIC else LayoutMode.ENGLISH_LOWER
            } else {
                LayoutMode.TASHKEEL_AND_DECOR
            }
            refreshMainBody()
        }

        addToolBtn("⚙ ضبط") {
            val intent = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
        }
    }

    private fun updateQuickPasteStrip() {
        val strip = quickPasteStrip ?: return
        val theme = prefs.theme
        strip.removeAllViews()

        // سهم تحريك المؤشر يسار
        strip.addView(smallArrowBtn("◀") { moveCursor(-1) })

        val latest = clipboardStore.getLatest()
        val centerText = when {
            prefs.decorationEnabled -> {
                val styleName = DecorationEngine.arabicStyleNames.getOrElse(prefs.arabicDecorationStyle) { "" }
                "✨ $styleName (اضغط مطولاً لتغيير النمط)"
            }
            latest != null -> {
                val preview = latest.text.replace("\n", " ").take(34)
                "📋 لصق سريع: $preview"
            }
            else -> "⚡ كيبورد أبو عبود نت • إصدار أندرويد 16"
        }

        val pill = TextView(this).apply {
            text = centerText
            maxLines = 1
            gravity = Gravity.CENTER
            setTextColor(if (latest != null && !prefs.decorationEnabled) theme.accentColor else theme.textColor)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setPadding(dp(8), dp(4), dp(8), dp(4))
            background = roundedBg(theme.keyColor, dp(12).toFloat(), theme.borderColor)
            layoutParams = LinearLayout.LayoutParams(0, dp(28), 1f).apply {
                marginStart = dp(4)
                marginEnd = dp(4)
            }
            setOnClickListener {
                performFeedback(this)
                if (latest != null && !prefs.decorationEnabled) {
                    currentInputConnection?.commitText(latest.text, 1)
                } else if (prefs.decorationEnabled) {
                    val nextStyle = (prefs.arabicDecorationStyle + 1) % DecorationEngine.arabicStyleNames.size
                    prefs.arabicDecorationStyle = nextStyle
                    updateQuickPasteStrip()
                } else {
                    activePanel = "CLIPBOARD"
                    refreshMainBody()
                }
            }
        }
        strip.addView(pill)

        // سهم تحريك المؤشر يمين
        strip.addView(smallArrowBtn("▶") { moveCursor(1) })
    }

    private fun smallArrowBtn(symbol: String, onClick: () -> Unit): TextView {
        val theme = prefs.theme
        return TextView(this).apply {
            text = symbol
            gravity = Gravity.CENTER
            setTextColor(theme.textColor)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            background = roundedBg(theme.specialKeyColor, dp(8).toFloat(), theme.borderColor)
            layoutParams = LinearLayout.LayoutParams(dp(32), dp(28))
            setOnClickListener {
                performFeedback(this)
                onClick()
            }
        }
    }

    private fun moveCursor(delta: Int) {
        val keyCode = if (delta < 0) KeyEvent.KEYCODE_DPAD_LEFT else KeyEvent.KEYCODE_DPAD_RIGHT
        currentInputConnection?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
        currentInputConnection?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
    }

    private fun renderKeys() {
        val box = keysContainer ?: return
        box.removeAllViews()

        if (prefs.showNumberRow && currentMode != LayoutMode.SYMBOLS) {
            val nums = if (isArabicLanguage) KeyboardLayouts.numberRowAr else KeyboardLayouts.numberRowEn
            box.addView(buildKeyRow(nums, compact = true))
        }

        val rows = when (currentMode) {
            LayoutMode.ARABIC -> KeyboardLayouts.arabicRows
            LayoutMode.ENGLISH_LOWER -> KeyboardLayouts.englishLowerRows
            LayoutMode.ENGLISH_UPPER -> KeyboardLayouts.englishUpperRows
            LayoutMode.SYMBOLS -> KeyboardLayouts.symbolsRows
            LayoutMode.TASHKEEL_AND_DECOR -> KeyboardLayouts.tashkeelAndDecorRows
        }

        rows.forEachIndexed { index, rowKeys ->
            if (index == rows.lastIndex) {
                box.addView(buildBottomAlphaRow(rowKeys))
            } else {
                box.addView(buildKeyRow(rowKeys))
            }
        }

        box.addView(buildActionRow())
    }

    private fun buildKeyRow(keys: List<String>, compact: Boolean = false): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(if (compact) (prefs.keyHeightDp - 10) else prefs.keyHeightDp)
            ).apply {
                topMargin = dp(3)
            }
        }
        for (label in keys) {
            val alt = KeyboardLayouts.longPressHints[label]
            row.addView(
                createFastKey(
                    label = label,
                    weight = 1f,
                    isSpecial = compact,
                    onLongPress = if (alt != null) {
                        { handleCharacterPress(alt) }
                    } else null
                ) {
                    handleCharacterPress(label)
                }
            )
        }
        return row
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun buildBottomAlphaRow(keys: List<String>): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(prefs.keyHeightDp)
            ).apply {
                topMargin = dp(3)
            }
        }

        if (currentMode == LayoutMode.ENGLISH_LOWER || currentMode == LayoutMode.ENGLISH_UPPER) {
            val shiftLabel = if (currentMode == LayoutMode.ENGLISH_UPPER) "⬆" else "⇧"
            row.addView(createFastKey(shiftLabel, weight = 1.4f, isSpecial = true) {
                currentMode = if (currentMode == LayoutMode.ENGLISH_LOWER) {
                    LayoutMode.ENGLISH_UPPER
                } else {
                    LayoutMode.ENGLISH_LOWER
                }
                renderKeys()
            })
        }

        for (label in keys) {
            val alt = KeyboardLayouts.longPressHints[label]
            row.addView(
                createFastKey(
                    label = label,
                    weight = 1f,
                    isSpecial = false,
                    onLongPress = if (alt != null) {
                        { handleCharacterPress(alt) }
                    } else null
                ) {
                    handleCharacterPress(label)
                }
            )
        }

        // زر الحذف مع حذف مستمر سريع عند الاستمرار بالضغط
        val theme = prefs.theme
        val normalBg = roundedBg(theme.specialKeyColor, dp(8).toFloat(), theme.borderColor)
        val pressedBg = roundedBg(theme.keyPressedColor, dp(8).toFloat(), theme.accentColor)
        val delKey = TextView(this).apply {
            text = "⌫"
            gravity = Gravity.CENTER
            setTextColor(theme.textColor)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            background = normalBg
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.5f).apply {
                marginStart = dp(2)
                marginEnd = dp(2)
            }
            setOnTouchListener { v, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        v.background = pressedBg
                        performFeedback(v)
                        handleBackspace(deleteWord = false)
                        backspaceRepeating = true
                        backspaceCount = 0
                        handler.postDelayed(backspaceRunnable, 340L)
                        true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        v.background = normalBg
                        backspaceRepeating = false
                        handler.removeCallbacks(backspaceRunnable)
                        true
                    }
                    else -> false
                }
            }
        }
        row.addView(delKey)

        return row
    }

    private fun buildActionRow(): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(prefs.keyHeightDp)
            ).apply {
                topMargin = dp(4)
            }
        }

        row.addView(createFastKey(if (currentMode == LayoutMode.SYMBOLS) "أبج" else "123", weight = 1.3f, isSpecial = true) {
            currentMode = if (currentMode == LayoutMode.SYMBOLS) {
                if (isArabicLanguage) LayoutMode.ARABIC else LayoutMode.ENGLISH_LOWER
            } else {
                LayoutMode.SYMBOLS
            }
            renderKeys()
        })

        row.addView(createFastKey(if (isArabicLanguage) "EN" else "عربي", weight = 1.2f, isSpecial = true) {
            isArabicLanguage = !isArabicLanguage
            currentMode = if (isArabicLanguage) LayoutMode.ARABIC else LayoutMode.ENGLISH_LOWER
            currentWordBuffer.clear()
            renderKeys()
        })

        val spaceTitle = if (prefs.decorationEnabled) "✨ أبو عبود نت ✨" else "أبو عبود نت"
        row.addView(createFastKey(spaceTitle, weight = 4.2f, isSpecial = false) {
            handleSpacePress()
        })

        val punct = if (isArabicLanguage) "،" else "."
        row.addView(
            createFastKey(
                label = punct,
                weight = 0.9f,
                isSpecial = true,
                onLongPress = { handleCharacterPress(if (isArabicLanguage) "؟" else "!") }
            ) {
                handleCharacterPress(punct)
            }
        )

        row.addView(createFastKey("↵", weight = 1.5f, isSpecial = true, useAccent = true) {
            handleEnterPress()
        })

        return row
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createFastKey(
        label: String,
        weight: Float,
        isSpecial: Boolean,
        useAccent: Boolean = false,
        onLongPress: (() -> Unit)? = null,
        onTap: () -> Unit
    ): TextView {
        val theme = prefs.theme
        val baseColor = when {
            useAccent -> theme.accentColor
            isSpecial -> theme.specialKeyColor
            else -> theme.keyColor
        }
        val normalBg = roundedBg(baseColor, dp(8).toFloat(), if (useAccent) theme.accentColor else theme.borderColor)
        val pressedBg = roundedBg(theme.keyPressedColor, dp(8).toFloat(), theme.accentColor)

        var longPressTriggered = false
        var longPressRunnable: Runnable? = null

        return TextView(this).apply {
            text = label
            gravity = Gravity.CENTER
            maxLines = 1
            setTextColor(if (useAccent) 0xFF07131F.toInt() else theme.textColor)
            typeface = if (useAccent || label.length > 2) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            setTextSize(TypedValue.COMPLEX_UNIT_SP, if (label.length > 2) 13f else prefs.fontSizeSp)
            background = normalBg
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight).apply {
                marginStart = dp(2)
                marginEnd = dp(2)
            }
            setOnTouchListener { v, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        v.background = pressedBg
                        v.scaleX = 0.94f
                        v.scaleY = 0.94f
                        longPressTriggered = false
                        if (onLongPress != null) {
                            val r = Runnable {
                                longPressTriggered = true
                                performFeedback(v)
                                onLongPress()
                            }
                            longPressRunnable = r
                            handler.postDelayed(r, 380L)
                        }
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        v.background = normalBg
                        v.scaleX = 1f
                        v.scaleY = 1f
                        longPressRunnable?.let { handler.removeCallbacks(it) }
                        if (!longPressTriggered) {
                            performFeedback(v)
                            onTap()
                        }
                        true
                    }
                    MotionEvent.ACTION_CANCEL -> {
                        v.background = normalBg
                        v.scaleX = 1f
                        v.scaleY = 1f
                        longPressRunnable?.let { handler.removeCallbacks(it) }
                        true
                    }
                    else -> false
                }
            }
        }
    }

    private fun renderActivePanel() {
        val panel = panelContainer ?: return
        val theme = prefs.theme
        panel.removeAllViews()

        when (activePanel) {
            "CLIPBOARD" -> {
                // شريط تحكم سريع للحافظة (نسخ، لصق، تحديد الكل، مسح غير المثبت، رجوع)
                val controls = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    setPadding(dp(4), dp(4), dp(4), dp(4))
                }
                fun addCtrl(title: String, onClick: () -> Unit) {
                    val b = TextView(this).apply {
                        text = title
                        gravity = Gravity.CENTER
                        setTextColor(theme.textColor)
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
                        background = roundedBg(theme.specialKeyColor, dp(8).toFloat(), theme.borderColor)
                        setPadding(dp(4), dp(6), dp(4), dp(6))
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                            marginStart = dp(2)
                            marginEnd = dp(2)
                        }
                        setOnClickListener {
                            performFeedback(this)
                            onClick()
                        }
                    }
                    controls.addView(b)
                }

                addCtrl("تحديد الكل") {
                    currentInputConnection?.performContextMenuAction(android.R.id.selectAll)
                }
                addCtrl("نسخ") {
                    currentInputConnection?.performContextMenuAction(android.R.id.copy)
                    handler.postDelayed({
                        captureSystemClipboard()
                        renderActivePanel()
                        updateQuickPasteStrip()
                    }, 150L)
                }
                addCtrl("لصق") {
                    currentInputConnection?.performContextMenuAction(android.R.id.paste)
                }
                addCtrl("مسح الكل") {
                    clipboardStore.clearUnpinned()
                    renderActivePanel()
                    updateQuickPasteStrip()
                }
                addCtrl("رجوع ⌨") {
                    activePanel = null
                    refreshMainBody()
                }
                panel.addView(controls)

                val scroll = ScrollView(this).apply {
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(195))
                }
                val listLayout = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(6), dp(4), dp(6), dp(6))
                }

                val clips = clipboardStore.getAll()
                if (clips.isEmpty()) {
                    listLayout.addView(infoText("الحافظة جاهزة! اضغط زر (نسخ) أعلاه أو انسخ أي نص من أي تطبيق ليظهر هنا فوراً."))
                } else {
                    for (clip in clips) {
                        val row = LinearLayout(this).apply {
                            orientation = LinearLayout.HORIZONTAL
                            gravity = Gravity.CENTER_VERTICAL
                            background = roundedBg(theme.keyColor, dp(10).toFloat(), theme.borderColor)
                            setPadding(dp(10), dp(8), dp(10), dp(8))
                            layoutParams = LinearLayout.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.WRAP_CONTENT
                            ).apply { bottomMargin = dp(6) }
                        }
                        val tv = TextView(this).apply {
                            text = (if (clip.pinned) "📌 " else "") + clip.text
                            maxLines = 2
                            setTextColor(theme.textColor)
                            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
                            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                            setOnClickListener {
                                performFeedback(this)
                                currentInputConnection?.commitText(clip.text, 1)
                            }
                        }
                        val pinBtn = TextView(this).apply {
                            text = if (clip.pinned) "فك" else "تثبيت"
                            setTextColor(theme.accentColor)
                            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                            setPadding(dp(8), dp(4), dp(8), dp(4))
                            setOnClickListener {
                                clipboardStore.togglePin(clip.text)
                                renderActivePanel()
                            }
                        }
                        val delBtn = TextView(this).apply {
                            text = "✕"
                            setTextColor(0xFFEF5350.toInt())
                            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                            setPadding(dp(8), dp(4), dp(4), dp(4))
                            setOnClickListener {
                                clipboardStore.deleteClip(clip.text)
                                renderActivePanel()
                                updateQuickPasteStrip()
                            }
                        }
                        row.addView(tv)
                        row.addView(pinBtn)
                        row.addView(delBtn)
                        listLayout.addView(row)
                    }
                }
                scroll.addView(listLayout)
                panel.addView(scroll)
            }

            "SHORTCUTS" -> {
                val scroll = ScrollView(this).apply {
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(220))
                }
                val listLayout = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(6), dp(6), dp(6), dp(6))
                }
                val shortcuts = shortcutsManager.getAll()
                if (shortcuts.isEmpty()) {
                    listLayout.addView(infoText("لا توجد اختصارات بعد. أضف اختصاراتك من شاشة الإعدادات."))
                } else {
                    for (sc in shortcuts) {
                        val itemView = TextView(this).apply {
                            text = "⚡ [${sc.trigger}]  ←  ${sc.expansion}"
                            setTextColor(theme.textColor)
                            background = roundedBg(theme.keyColor, dp(10).toFloat(), theme.borderColor)
                            setPadding(dp(12), dp(10), dp(12), dp(10))
                            layoutParams = LinearLayout.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.WRAP_CONTENT
                            ).apply { bottomMargin = dp(6) }
                            setOnClickListener {
                                performFeedback(this)
                                currentInputConnection?.commitText(sc.expansion + " ", 1)
                            }
                        }
                        listLayout.addView(itemView)
                    }
                }
                scroll.addView(listLayout)
                panel.addView(scroll)
            }

            "EMOJI" -> {
                val scroll = ScrollView(this).apply {
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(220))
                }
                val listLayout = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(6), dp(6), dp(6), dp(6))
                }
                val chunked = KeyboardLayouts.quickEmojis.chunked(6)
                for (rowEmojis in chunked) {
                    val row = LinearLayout(this).apply {
                        orientation = LinearLayout.HORIZONTAL
                        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42))
                    }
                    for (emoji in rowEmojis) {
                        val btn = TextView(this).apply {
                            text = emoji
                            gravity = Gravity.CENTER
                            setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
                            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                            setOnClickListener {
                                performFeedback(this)
                                currentInputConnection?.commitText(emoji, 1)
                            }
                        }
                        row.addView(btn)
                    }
                    listLayout.addView(row)
                }
                scroll.addView(listLayout)
                panel.addView(scroll)
            }
        }
    }

    private fun handleCharacterPress(raw: String) {
        val ic = currentInputConnection ?: return
        val output = if (prefs.decorationEnabled && raw.length == 1) {
            val ch = raw[0]
            when {
                ch in '\u0621'..'\u064A' -> DecorationEngine.decorateCharArabic(ch, prefs.arabicDecorationStyle)
                ch in 'A'..'Z' || ch in 'a'..'z' -> DecorationEngine.decorateCharEnglish(ch, prefs.englishDecorationStyle)
                else -> raw
            }
        } else {
            raw
        }
        ic.commitText(output, 1)
        currentWordBuffer.append(raw)
    }

    private fun handleSpacePress() {
        val ic = currentInputConnection ?: return
        val typedWord = currentWordBuffer.toString().trim()

        if (prefs.shortcutsEnabled && typedWord.isNotEmpty()) {
            val expanded = shortcutsManager.findExpansion(typedWord)
            if (expanded != null) {
                ic.deleteSurroundingText(typedWord.length, 0)
                val finalOut = if (prefs.decorationEnabled) {
                    DecorationEngine.decorateWordOrPhraseArabic(expanded, prefs.arabicDecorationStyle)
                } else {
                    expanded
                }
                ic.commitText("$finalOut ", 1)
                currentWordBuffer.clear()
                return
            }
        }

        ic.commitText(" ", 1)
        currentWordBuffer.clear()
    }

    private fun handleBackspace(deleteWord: Boolean) {
        val ic = currentInputConnection ?: return
        if (deleteWord) {
            val before = ic.getTextBeforeCursor(40, 0)?.toString().orEmpty()
            val trimmed = before.trimEnd()
            val lastSpace = trimmed.lastIndexOf(' ')
            val count = if (lastSpace == -1) before.length else (before.length - lastSpace - 1)
            if (count > 0) {
                ic.deleteSurroundingText(count, 0)
            }
            currentWordBuffer.clear()
        } else {
            ic.deleteSurroundingText(1, 0)
            if (currentWordBuffer.isNotEmpty()) {
                currentWordBuffer.deleteCharAt(currentWordBuffer.length - 1)
            }
        }
    }

    private fun handleEnterPress() {
        currentWordBuffer.clear()
        currentInputConnection?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
        currentInputConnection?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
    }

    private fun performFeedback(view: View) {
        if (prefs.vibrationEnabled) {
            view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        }
        if (prefs.soundEnabled) {
            audioManager?.playSoundEffect(AudioManager.FX_KEY_CLICK, 0.45f)
        }
    }

    private fun infoText(msg: String): TextView = TextView(this).apply {
        text = msg
        setTextColor(prefs.theme.textColor)
        gravity = Gravity.CENTER
        setPadding(dp(12), dp(24), dp(12), dp(24))
    }

    private fun roundedBg(color: Int, radius: Float, strokeColor: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius
            setStroke(dp(1), strokeColor)
        }

    private fun dp(value: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value.toFloat(), resources.displayMetrics).toInt()
}

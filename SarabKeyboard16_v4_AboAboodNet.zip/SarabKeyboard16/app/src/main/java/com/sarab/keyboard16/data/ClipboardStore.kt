package com.sarab.keyboard16.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class ClipItem(
    val text: String,
    val pinned: Boolean = false
)

class ClipboardStore(context: Context) {
    private val prefs = context.getSharedPreferences("sarab_clipboard_store", Context.MODE_PRIVATE)
    private val keyClips = "clips_json"
    private val maxItems = 50

    fun getAll(): MutableList<ClipItem> {
        val raw = prefs.getString(keyClips, "[]") ?: "[]"
        val list = mutableListOf<ClipItem>()
        runCatching {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val t = obj.optString("text")
                if (t.isNotBlank()) {
                    list.add(ClipItem(t, obj.optBoolean("pinned", false)))
                }
            }
        }
        return list.sortedByDescending { it.pinned }.toMutableList()
    }

    fun getLatest(): ClipItem? = getAll().firstOrNull()

    fun addClip(text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        val list = getAll()
        val wasPinned = list.firstOrNull { it.text == clean }?.pinned ?: false
        list.removeAll { it.text == clean }
        list.add(0, ClipItem(clean, wasPinned))
        val trimmed = list.sortedByDescending { it.pinned }.take(maxItems)
        saveAll(trimmed)
    }

    fun togglePin(text: String) {
        val list = getAll().map {
            if (it.text == text) it.copy(pinned = !it.pinned) else it
        }
        saveAll(list.sortedByDescending { it.pinned })
    }

    fun deleteClip(text: String) {
        val list = getAll()
        list.removeAll { it.text == text }
        saveAll(list)
    }

    fun clearUnpinned() {
        val list = getAll().filter { it.pinned }
        saveAll(list)
    }

    private fun saveAll(list: List<ClipItem>) {
        val arr = JSONArray()
        for (item in list) {
            val obj = JSONObject()
            obj.put("text", item.text)
            obj.put("pinned", item.pinned)
            arr.put(obj)
        }
        prefs.edit().putString(keyClips, arr.toString()).apply()
    }
}

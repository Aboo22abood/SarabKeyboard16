package com.sarab.keyboard16.engine

enum class LayoutMode {
    ARABIC,
    ENGLISH_LOWER,
    ENGLISH_UPPER,
    SYMBOLS,
    TASHKEEL_AND_DECOR
}

object KeyboardLayouts {

    val numberRowAr = listOf("١", "٢", "٣", "٤", "٥", "٦", "٧", "٨", "٩", "٠")
    val numberRowEn = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")

    // الترتيب العربي القياسي الكامل (من اليسار إلى اليمين — يشمل جميع الحروف بما فيها د و ذ)
    val arabicRows = listOf(
        listOf("ض", "ص", "ث", "ق", "ف", "غ", "ع", "ه", "خ", "ح", "ج", "د"),
        listOf("ش", "س", "ي", "ب", "ل", "ا", "ت", "ن", "م", "ك", "ط"),
        listOf("ذ", "ئ", "ء", "ؤ", "ر", "ى", "ة", "و", "ز", "ظ")
    )

    // بدائل الضغط المطول السريعة للحروف العربية
    val longPressHints = mapOf(
        "ا" to "أ",
        "أ" to "إ",
        "ل" to "لا",
        "ه" to "ة",
        "ي" to "ى",
        "و" to "ؤ",
        "د" to "ذ",
        "ك" to "گ",
        "ب" to "پ",
        "ج" to "چ",
        "ت" to "ـ",
        "،" to "؟",
        "." to "!"
    )

    val englishLowerRows = listOf(
        listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p"),
        listOf("a", "s", "d", "f", "g", "h", "j", "k", "l"),
        listOf("z", "x", "c", "v", "b", "n", "m")
    )

    val englishUpperRows = listOf(
        listOf("Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P"),
        listOf("A", "S", "D", "F", "G", "H", "J", "K", "L"),
        listOf("Z", "X", "C", "V", "B", "N", "M")
    )

    val symbolsRows = listOf(
        listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"),
        listOf("@", "#", "$", "%", "&", "-", "+", "(", ")", "/"),
        listOf("*", "\"", "'", ":", ";", "!", "?", "،", "؟", ".")
    )

    val tashkeelAndDecorRows = listOf(
        listOf("َ", "ً", "ُ", "ٌ", "ِ", "ٍ", "ْ", "ّ", "ـ", "ٓ"),
        listOf("★", "☆", "♥", "♡", "❀", "✿", "❖", "✦", "✧", "♛"),
        listOf("꧁", "꧂", "«", "»", "『", "』", "【", "】", "ـہ", "ـآ")
    )

    val quickEmojis = listOf(
        "😀", "😂", "🤣", "😊", "😍", "🥰", "😘", "😎", "🤩", "🤔",
        "😅", "😢", "😭", "😡", "👍", "👎", "👏", "🙏", "🤝", "💪",
        "❤️", "💔", "🔥", "✨", "🌟", "🎉", "🌹", "🤲", "🕌", "⚡",
        "👑", "💎", "📶", "📡", "💻", "📱"
    )
}

package com.sarab.keyboard16.data

import android.content.Context
import android.content.SharedPreferences

enum class KeyboardTheme(
    val id: String,
    val titleAr: String,
    val bgColor: Int,
    val toolbarColor: Int,
    val keyColor: Int,
    val keyPressedColor: Int,
    val specialKeyColor: Int,
    val textColor: Int,
    val accentColor: Int,
    val borderColor: Int
) {
    ABO_ABOOD_ROYAL(
        "abo_abood_royal", "أبو عبود الملكي (أزرق وذهبي)",
        0xFF0B1120.toInt(), 0xFF111A2E.toInt(), 0xFF1A2540.toInt(), 0xFF283A63.toInt(),
        0xFF152038.toInt(), 0xFFF1F5F9.toInt(), 0xFF00C2FF.toInt(), 0xFF2B3E66.toInt()
    ),
    AMOLED_NEON(
        "amoled_neon", "أسود AMOLED نيون",
        0xFF000000.toInt(), 0xFF0A0A0F.toInt(), 0xFF16161F.toInt(), 0xFF2A2A3B.toInt(),
        0xFF12121C.toInt(), 0xFFFFFFFF.toInt(), 0xFF00E5FF.toInt(), 0xFF2B2B40.toInt()
    ),
    GOLD_LUXURY(
        "gold_luxury", "الذهبي الفاخر",
        0xFF14110D.toInt(), 0xFF1E1913.toInt(), 0xFF2A231A.toInt(), 0xFF3E3325.toInt(),
        0xFF241D15.toInt(), 0xFFFFE082.toInt(), 0xFFFFB300.toInt(), 0xFF52432F.toInt()
    ),
    MAGIC_PURPLE(
        "magic_purple", "البنفسجي الساحر",
        0xFF140D26.toInt(), 0xFF1E1438.toInt(), 0xFF2A1D4D.toInt(), 0xFF3E2C70.toInt(),
        0xFF231842.toInt(), 0xFFF3E8FF.toInt(), 0xFFC084FC.toInt(), 0xFF4F388C.toInt()
    ),
    EMERALD_PRO(
        "emerald_pro", "الأخضر الزمردي",
        0xFF071A15.toInt(), 0xFF0C261F.toInt(), 0xFF13382E.toInt(), 0xFF1E5244.toInt(),
        0xFF103027.toInt(), 0xFFECFDF5.toInt(), 0xFF10B981.toInt(), 0xFF23594A.toInt()
    ),
    CLASSIC_LIGHT(
        "classic_light", "الأبيض العصري",
        0xFFE6ECF5.toInt(), 0xFFDCE4F0.toInt(), 0xFFFFFFFF.toInt(), 0xFFD0DCEF.toInt(),
        0xFFCFD9E8.toInt(), 0xFF141C2B.toInt(), 0xFF1565C0.toInt(), 0xFFB8C6DB.toInt()
    );

    companion object {
        fun fromId(id: String?): KeyboardTheme =
            entries.firstOrNull { it.id == id } ?: ABO_ABOOD_ROYAL
    }
}

class KeyboardPrefs(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("sarab_keyboard_prefs", Context.MODE_PRIVATE)

    var decorationEnabled: Boolean
        get() = prefs.getBoolean("decoration_enabled", false)
        set(value) = prefs.edit().putBoolean("decoration_enabled", value).apply()

    var arabicDecorationStyle: Int
        get() = prefs.getInt("ar_dec_style", 0)
        set(value) = prefs.edit().putInt("ar_dec_style", value).apply()

    var englishDecorationStyle: Int
        get() = prefs.getInt("en_dec_style", 0)
        set(value) = prefs.edit().putInt("en_dec_style", value).apply()

    var showNumberRow: Boolean
        get() = prefs.getBoolean("show_number_row", true)
        set(value) = prefs.edit().putBoolean("show_number_row", value).apply()

    var vibrationEnabled: Boolean
        get() = prefs.getBoolean("vibration_enabled", true)
        set(value) = prefs.edit().putBoolean("vibration_enabled", value).apply()

    var soundEnabled: Boolean
        get() = prefs.getBoolean("sound_enabled", false)
        set(value) = prefs.edit().putBoolean("sound_enabled", value).apply()

    var shortcutsEnabled: Boolean
        get() = prefs.getBoolean("shortcuts_enabled", true)
        set(value) = prefs.edit().putBoolean("shortcuts_enabled", value).apply()

    var popupPreviewEnabled: Boolean
        get() = prefs.getBoolean("popup_preview_enabled", true)
        set(value) = prefs.edit().putBoolean("popup_preview_enabled", value).apply()

    var keyHeightDp: Int
        get() = prefs.getInt("key_height_dp", 46)
        set(value) = prefs.edit().putInt("key_height_dp", value.coerceIn(38, 62)).apply()

    var fontSizeSp: Float
        get() = prefs.getFloat("font_size_sp", 18f)
        set(value) = prefs.edit().putFloat("font_size_sp", value.coerceIn(14f, 24f)).apply()

    var theme: KeyboardTheme
        get() = KeyboardTheme.fromId(prefs.getString("theme_id", KeyboardTheme.ABO_ABOOD_ROYAL.id))
        set(value) = prefs.edit().putString("theme_id", value.id).apply()

    var versionTag: Int
        get() = prefs.getInt("settings_version", 0)
        set(value) = prefs.edit().putInt("settings_version", value).apply()

    fun bumpVersion() {
        versionTag += 1
    }
}

package com.sarab.keyboard16.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class TextShortcut(
    val trigger: String,
    val expansion: String
)

class ShortcutsManager(context: Context) {
    private val prefs = context.getSharedPreferences("sarab_shortcuts_store", Context.MODE_PRIVATE)
    private val keyList = "shortcuts_json"
    private var cachedMap: Map<String, String> = emptyMap()
    private var lastLoadedRaw: String? = null

    init {
        if (!prefs.contains(keyList)) {
            saveAll(defaultShortcuts())
        }
        reloadCacheIfNeeded()
    }

    private fun reloadCacheIfNeeded() {
        val raw = prefs.getString(keyList, "[]") ?: "[]"
        if (raw == lastLoadedRaw) return
        lastLoadedRaw = raw
        val map = LinkedHashMap<String, String>()
        runCatching {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val t = obj.optString("trigger").trim()
                val e = obj.optString("expansion")
                if (t.isNotEmpty() && e.isNotEmpty()) {
                    map[t] = e
                }
            }
        }
        cachedMap = map
    }

    fun getAll(): MutableList<TextShortcut> {
        reloadCacheIfNeeded()
        return cachedMap.entries.map { TextShortcut(it.key, it.value) }.toMutableList()
    }

    fun findExpansion(trigger: String): String? {
        reloadCacheIfNeeded()
        return cachedMap[trigger.trim()]
    }

    fun addOrUpdate(trigger: String, expansion: String) {
        val cleanTrigger = trigger.trim()
        if (cleanTrigger.isEmpty() || expansion.isEmpty()) return
        val list = getAll()
        list.removeAll { it.trigger == cleanTrigger }
        list.add(0, TextShortcut(cleanTrigger, expansion))
        saveAll(list)
    }

    fun remove(trigger: String) {
        val list = getAll()
        list.removeAll { it.trigger == trigger }
        saveAll(list)
    }

    fun exportToJson(): String {
        val arr = JSONArray()
        for (item in getAll()) {
            val obj = JSONObject()
            obj.put("trigger", item.trigger)
            obj.put("expansion", item.expansion)
            arr.put(obj)
        }
        return arr.toString(2)
    }

    fun importFromJson(jsonText: String, merge: Boolean = true): Int {
        val incoming = mutableListOf<TextShortcut>()
        val arr = JSONArray(jsonText)
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            val t = obj.optString("trigger").trim()
            val e = obj.optString("expansion")
            if (t.isNotEmpty() && e.isNotEmpty()) {
                incoming.add(TextShortcut(t, e))
            }
        }
        val finalList = if (merge) {
            val existing = getAll()
            for (item in incoming) {
                existing.removeAll { it.trigger == item.trigger }
                existing.add(item)
            }
            existing
        } else {
            incoming
        }
        saveAll(finalList)
        return incoming.size
    }

    private fun saveAll(list: List<TextShortcut>) {
        val arr = JSONArray()
        for (item in list) {
            val obj = JSONObject()
            obj.put("trigger", item.trigger)
            obj.put("expansion", item.expansion)
            arr.put(obj)
        }
        val serialized = arr.toString()
        prefs.edit().putString(keyList, serialized).apply()
        lastLoadedRaw = null
        reloadCacheIfNeeded()
    }

    private fun defaultShortcuts(): List<TextShortcut> = listOf(
        TextShortcut("س", "السلام عليكم ورحمة الله وبركاته"),
        TextShortcut("و", "وعليكم السلام ورحمة الله وبركاته"),
        TextShortcut("ح", "الحمد لله رب العالمين"),
        TextShortcut("ش", "شكراً جزيلاً، يعطيك العافية"),
        TextShortcut("ص", "اللهم صلِّ وسلم على نبينا محمد"),
        TextShortcut("م", "مساء الخير، كيف الحال؟"),
        TextShortcut("صب", "صباح الخير والنور"),
        TextShortcut("ابو", "أبو عبود نت لخدمات الإنترنت والشبكات")
    )
}

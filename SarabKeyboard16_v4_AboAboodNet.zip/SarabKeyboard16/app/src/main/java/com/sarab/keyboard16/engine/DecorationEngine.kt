package com.sarab.keyboard16.engine

object DecorationEngine {

    val arabicStyleNames = listOf(
        "التطويل الملكي (كـتـابـة)",
        "التشكيل الاحترافي (كَتِابَة)",
        "حروف السراب المميزة (گتآبـة)",
        "تطويل مزدوج فاخر (كــتــابــة)",
        "زخرفة النجوم (★ نص ★)",
        "زخرفة الأجنحة (꧁ نص ꧂)"
    )

    val englishStyleNames = listOf(
        "Bold Serif (𝐀𝐁𝐂)",
        "Script Fancy (𝒜𝐵𝒞)",
        "Double Struck (𝔸𝔹ℂ)",
        "Monospace (𝙰𝙱𝙲)",
        "Small Caps (ᴀʙᴄ)"
    )

    private val stretchableArabic = setOf(
        'ب', 'ت', 'ث', 'ج', 'ح', 'خ', 'س', 'ش', 'ص', 'ض',
        'ط', 'ظ', 'ع', 'غ', 'ف', 'ق', 'ك', 'ل', 'م', 'ن', 'ه', 'ي', 'ئ'
    )

    private val stylishArabicMap = mapOf(
        'ا' to "آ",
        'أ' to "أّ",
        'ب' to "بّ",
        'ت' to "تٌ",
        'ث' to "ثً",
        'ج' to "جٍ",
        'ح' to "حً",
        'خ' to "خـ",
        'س' to "سـ",
        'ش' to "شـ",
        'ص' to "صـ",
        'ض' to "ضـ",
        'ع' to "عٌ",
        'غ' to "غـ",
        'ف' to "فُ",
        'ق' to "قـ",
        'ك' to "گ",
        'ل' to "لُ",
        'م' to "مـ",
        'ن' to "نِ",
        'ه' to "هـ",
        'و' to "وٌ",
        'ي' to "يَ"
    )

    private val tashkeelCycle = charArrayOf('\u064E', '\u0650', '\u064F', '\u0652')

    fun decorateCharArabic(ch: Char, styleIndex: Int): String {
        return when (styleIndex) {
            0 -> if (ch in stretchableArabic) "${ch}ـ" else ch.toString()
            1 -> if (ch in '\u0621'..'\u064A') {
                val mark = tashkeelCycle[ch.code % tashkeelCycle.size]
                "$ch$mark"
            } else ch.toString()
            2 -> stylishArabicMap[ch] ?: ch.toString()
            3 -> if (ch in stretchableArabic) "${ch}ــ" else ch.toString()
            4 -> if (ch in stretchableArabic) "${ch}ـ" else ch.toString()
            5 -> if (ch in stretchableArabic) "${ch}ـ" else ch.toString()
            else -> ch.toString()
        }
    }

    fun decorateWordOrPhraseArabic(text: String, styleIndex: Int): String {
        val core = text.map { decorateCharArabic(it, styleIndex) }.joinToString("")
        return when (styleIndex) {
            4 -> "★ $core ★"
            5 -> "꧁ $core ꧂"
            else -> core
        }
    }

    fun decorateCharEnglish(ch: Char, styleIndex: Int): String {
        return when (styleIndex) {
            0 -> mapUnicodeOffset(ch, 0x1D400, 0x1D41A)
            1 -> mapUnicodeOffset(ch, 0x1D4D0, 0x1D4EA)
            2 -> mapUnicodeOffset(ch, 0x1D538, 0x1D552)
            3 -> mapUnicodeOffset(ch, 0x1D670, 0x1D68A)
            4 -> mapSmallCaps(ch)
            else -> ch.toString()
        }
    }

    private fun mapUnicodeOffset(ch: Char, upperStart: Int, lowerStart: Int): String {
        return when (ch) {
            in 'A'..'Z' -> String(Character.toChars(upperStart + (ch - 'A')))
            in 'a'..'z' -> String(Character.toChars(lowerStart + (ch - 'a')))
            else -> ch.toString()
        }
    }

    private fun mapSmallCaps(ch: Char): String {
        val smallCaps = "ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀsᴛᴜᴠᴡxʏᴢ"
        val lower = ch.lowercaseChar()
        return if (lower in 'a'..'z') smallCaps[lower - 'a'].toString() else ch.toString()
    }
}
